 
select * from employ
      -- WHERE OPERATORS
-------- -----arthematic operators
select * from employ where locality = 'kukatpally'
select * from employ where m_salary > 20000
select * from employ where M_salary < 20000
select * from employ where m_salary <> 16000
select * from employ where m_salary >= 16000
select * from employ where m_salary <= 16000
-------------bitwise operators
select * from employ where emp_job = 'sealsmen' and m_salary >=22000
select * from employ where emp_job = 'sealsmen' or emp_job = 'sealsgirl'
-------------logical operators
select * from employ where  locality in ('kukatpally','panjagutta','nizampet')
select * from employ where e_id between 1 and 9
select * from employ where emp_job like '%_men'
select * from employ where emp_job like 'man_%'
select * from employ where emp_job like '%_an_%'
select * from employ where not locality =   'hitec city' 
