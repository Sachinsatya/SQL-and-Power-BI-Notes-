
DROP TABLE IF EXISTS [ORDERS]

DROP TABLE IF EXISTS [Customers]

CREATE TABLE [dbo].[Customers](
	[Cust_Id] [int] NOT NULL,
	[Cust_name] [varchar](100) NOT NULL,
	[Location] [varchar](100) NULL,
	[Mobile] [varchar](10) NULL,
	[PIN] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Cust_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ORDERS]    Script Date: 13-11-2022 18:35:27 ******/

CREATE TABLE [dbo].[ORDERS](
	[Order_Id] [int] NOT NULL,
	[Order_Date] [date] NULL,
	[Order_Time] [time](7) NULL,
	[Order_Amount] [numeric](18, 2) NULL,
	[Cust_Id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Order_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (1, N'Gautham', N'Kolkata', N'1111111111', 521225)
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (2, N'Amritava', N'Kolkata', N'2222222222', 700002)
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (3, N'Oviya', N'Bengaluru', N'3333333333', 530055)
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (4, N'Susovan', 'Bengaluru', N'4444444444', 530065)
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (5, N'Aditi', N'Hyderabad', N'5555555555', 500072)
GO
INSERT [dbo].[Customers] ([Cust_Id], [Cust_name], [Location], [Mobile], [PIN]) VALUES (6, N'Srinivas', N'Hyderabad', N'6666666666', 500072)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1001, CAST(N'2022-09-30' AS Date), CAST(N'22:54:00' AS Time), CAST(1025.65 AS Numeric(18, 2)), 1)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1002, CAST(N'2022-10-02' AS Date), CAST(N'20:45:00' AS Time), CAST(1025.65 AS Numeric(18, 2)), 1)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1003, CAST(N'2022-10-05' AS Date), CAST(N'17:54:00' AS Time), CAST(1066.89 AS Numeric(18, 2)), 2)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1004, CAST(N'2022-10-05' AS Date), CAST(N'21:41:00' AS Time), CAST(206.50 AS Numeric(18, 2)), 2)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1005, CAST(N'2022-10-07' AS Date), CAST(N'13:50:00' AS Time), CAST(1254.78 AS Numeric(18, 2)), 2)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1006, CAST(N'2022-10-05' AS Date), CAST(N'21:41:00' AS Time), CAST(2000.50 AS Numeric(18, 2)), 3)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1007, CAST(N'2022-10-07' AS Date), CAST(N'13:50:00' AS Time), CAST(3500.78 AS Numeric(18, 2)), 4)
GO
INSERT [dbo].[ORDERS] ([Order_Id], [Order_Date], [Order_Time], [Order_Amount], [Cust_Id]) VALUES (1008, CAST(N'2022-10-10' AS Date), CAST(N'09:43:00' AS Time), CAST(175.50 AS Numeric(18, 2)), NULL)
GO

/****** Object:  Index [UQ__Customer__6FAE078272854182]    Script Date: 13-11-2022 18:35:28 ******/
ALTER TABLE [dbo].[Customers] ADD UNIQUE NONCLUSTERED 
(
	[Mobile] ASC
)
GO
ALTER TABLE [dbo].[Customers] ADD  DEFAULT ('Hyderabad') FOR [Location]
GO
ALTER TABLE [dbo].[ORDERS]  WITH CHECK ADD FOREIGN KEY([Cust_Id])
REFERENCES [dbo].[Customers] ([Cust_Id])
GO
ALTER TABLE [dbo].[Customers]  WITH CHECK ADD CHECK  (([PIN]>(0)))
GO



SELECT * FROM Customers

SELECT * FROM ORDERS

--1. Retrieve the Customer name who has placed more orders
SELECT TOP 1 o.Cust_Id,c.Cust_Name, COUNT(*) orders_count
FROM Orders o
INNER JOIN Customers c 
	ON c.Cust_Id=o.Cust_Id
GROUP BY o.Cust_Id,c.Cust_Name
ORDER BY orders_count DESC

--2. Retrieve the Customer record who hasn't placed any orders

SELECT c.* 
FROM Customers c
LEFT JOIN Orders o
ON c.Cust_Id=o.Cust_Id
WHERE o.Cust_Id IS NULL

--3. Insert the record into Order table where Customer_Id doesn't exist in Customer Table and share the observation
INSERT INTO Orders VALUES (1007,'2022-10-10','09:43:00.0000000', 2250,99)

--4. Retrieve the Location wise Total Orders and Order_Amount

SELECT  c.[Location], SUM(Order_Amount) AS Order_Amount
FROM Orders o
INNER JOIN Customers c 
	ON c.Cust_Id=o.Cust_Id
GROUP BY c.[Location]


-------------------------------------------------------------------------
-- String functions usage
CREATE TABLE User_Details(Id INT,Email VARCHAR(100))

INSERT INTO User_Details VALUES (1, 'Srinivas.Jagarlamudi@gmail.com'),  (2, 'Amar.Srivatsav@gmail.com')
 ,(3, 'Rocky.Ming@gmail.com'),  (4, 'Farroq.Mulla@gmail.com')

 SELECT * 
 , SUBSTRING (Email,1,CHARINDEX('.',Email)-1) AS First_Name
 , SUBSTRING (Email,CHARINDEX('.',Email)+1,CHARINDEX('@',Email)-CHARINDEX('.',Email)-1) AS Last_Name
 FROM User_Details

 -- Date function usage
 -- First Day and Last day of the month
 DECLARE @date DATE
 SET @date='2022-10-11'
 SELECT  DATEADD(dd,-DAY(@date)+1, @date) AS FirstDay_of_the_month
 SELECT  DATEADD(dd,-DAY(DATEADD(mm,1,@date)), DATEADD(mm,1,@date))  AS LastDay_of_the_month

  