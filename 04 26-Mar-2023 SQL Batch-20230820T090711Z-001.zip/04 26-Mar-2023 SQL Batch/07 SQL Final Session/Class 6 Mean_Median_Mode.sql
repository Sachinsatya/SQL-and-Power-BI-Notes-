
--Median
Declare @Temp Table(Id Int Identity(1,1), Data Decimal(10,5))

Insert into @Temp Values(1)
Insert into @Temp Values(2)
Insert into @Temp Values(5)
Insert into @Temp Values(5)
Insert into @Temp Values(5)
Insert into @Temp Values(6)
Insert into @Temp Values(6)
Insert into @Temp Values(6)
Insert into @Temp Values(7)
Insert into @Temp Values(9)



Select	Top 50 Percent Data
From	@Temp
Order By Data


Select	Top 50 Percent Data
From	@Temp
Order By Data DESC



Select ((
		Select Top 1 Data
		From   (
				Select	Top 50 Percent Data
				From	@Temp
				Order By Data
				) As A
		Order By Data DESC) + 
		(
		Select Top 1 Data
		From   (
				Select	Top 50 Percent Data
				From	@Temp

				Order By Data DESC
				) As A
		Order By Data Asc)) / 2

-------------------------------------------
--MOde
Declare @Temp1 Table(Id Int Identity(1,1), Data Decimal(10,5))

Insert into @Temp1 Values(1)
Insert into @Temp1 Values(2)
Insert into @Temp1 Values(5)
Insert into @Temp1 Values(5)
Insert into @Temp1 Values(5)
Insert into @Temp1 Values(6)
Insert into @Temp1 Values(6)
Insert into @Temp1 Values(6)
Insert into @Temp1 Values(7)
Insert into @Temp1 Values(9)
Insert into @Temp1 Values(10)


SELECT DATA, COUNT(*) cnt
FROM   @Temp1
GROUP  BY DATA
ORDER  BY COUNT(*) DESC


SELECT TOP 1 DATA
FROM   @Temp1
GROUP  BY DATA
ORDER  BY COUNT(*) DESC

SELECT TOP 1 with ties DATA
FROM   @Temp1
GROUP  BY DATA
ORDER  BY COUNT(*) DESC